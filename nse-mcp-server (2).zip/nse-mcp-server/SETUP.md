# NSE/BSE MCP Server — Setup Guide
## Gives Claude live access to ALL NSE/BSE corporate data — FREE

---

## What Claude Can Do Once This Is Running

| Tool | What It Fetches |
|------|----------------|
| `get_corporate_announcements` | All filings/announcements for any stock |
| `get_result_dates` | Board meeting & result dates |
| `get_bulk_block_deals` | Bulk/block deals (all stocks or specific) |
| `get_shareholding_pattern` | Promoter / FII / DII / Public holding |
| `get_fii_dii_data` | Daily FII & DII buy/sell activity |
| `get_stock_quote` | Full quote: OHLC, 52W H/L, PE, circuit limits |
| `get_market_status` | Nifty/BankNifty/VIX + top gainers/losers |
| `get_upcoming_events` | Dividends, bonus, splits, AGMs (next 30 days) |
| `get_insider_trading` | SAST/promoter buying-selling disclosures |
| `search_announcements_by_keyword` | Search "order win", "QIP", "expansion" across stocks |

---

## STEP 1 — Deploy on Railway (Free, 5 minutes)

1. Go to https://railway.app and sign up (free)
2. Click **"New Project"** → **"Deploy from GitHub"**
3. Upload these 3 files to a new GitHub repo:
   - `index.js`
   - `package.json`
   - `railway.toml`
4. Railway auto-detects Node.js and deploys
5. Click **"Generate Domain"** in Railway settings
6. Your server URL will be: `https://your-app-name.up.railway.app`

**Test it:**
```
https://your-app-name.up.railway.app/health
```
Should return: `{"status":"ok","tools":10}`

---

## STEP 2 — Add to Claude.ai as a Connector

1. Go to **claude.ai** → Settings → **Connectors** (or Integrations)
2. Click **"Add custom connector"** or **"Add MCP server"**
3. Enter your Railway URL:
   ```
   https://your-app-name.up.railway.app/mcp
   ```
4. Name it: `NSE BSE Market Data`
5. Save

---

## STEP 3 — Test in Claude Chat

Ask Claude:
- *"Get corporate announcements for PREMEXPLN"*
- *"What are the upcoming dividend events this week?"*
- *"Show me today's bulk deals"*
- *"What is the FII activity today?"*
- *"Get shareholding pattern for SUPRAJIT"*

---

## Alternative: Run Locally (If You Have a Server)

```bash
# Clone / copy files
mkdir nse-mcp-server && cd nse-mcp-server
# paste index.js and package.json

npm install
npm start
# Server runs on http://localhost:3005

# Use ngrok to expose publicly (for Claude.ai connector):
npx ngrok http 3005
# Use the ngrok HTTPS URL as your connector URL
```

---

## Troubleshooting

**NSE returns empty data?**
NSE occasionally blocks IPs. Solution: add a delay between requests or use a residential proxy.

**CORS errors?**
Already handled — all routes have `Access-Control-Allow-Origin: *`

**Railway free tier limits?**
Railway gives $5 free credit/month. This server is very lightweight — should run free indefinitely.

---

## Cost: ₹0
- NSE/BSE APIs: Free (public)
- Railway hosting: Free tier
- No API keys needed
