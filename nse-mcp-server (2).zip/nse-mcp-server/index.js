/**
 * nse-mcp-server/index.js
 * Free NSE/BSE Public Data MCP Server for Claude.ai
 * Connects to Claude via MCP protocol — no API key needed
 * 
 * Data Sources: NSE India public APIs + BSE India
 * Deploy on: Railway / Render / Your VPS
 */

const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

// ─── NSE Headers (bypass bot detection) ───────────────────────────────────────
const NSE_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': '*/*',
  'Accept-Language': 'en-US,en;q=0.9',
  'Accept-Encoding': 'gzip, deflate, br',
  'Referer': 'https://www.nseindia.com/',
  'Connection': 'keep-alive',
  'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-origin',
};

// ─── Cookie jar for NSE session ───────────────────────────────────────────────
let nseCookies = '';

async function getNSECookies() {
  try {
    const res = await axios.get('https://www.nseindia.com/', {
      headers: NSE_HEADERS,
      timeout: 10000,
    });
    const setCookie = res.headers['set-cookie'];
    if (setCookie) {
      nseCookies = setCookie.map(c => c.split(';')[0]).join('; ');
    }
  } catch (e) {
    console.error('Cookie fetch failed:', e.message);
  }
}

async function nseGet(url) {
  if (!nseCookies) await getNSECookies();
  try {
    const res = await axios.get(url, {
      headers: { ...NSE_HEADERS, Cookie: nseCookies },
      timeout: 15000,
    });
    return res.data;
  } catch (e) {
    // Refresh cookies and retry once
    await getNSECookies();
    const res = await axios.get(url, {
      headers: { ...NSE_HEADERS, Cookie: nseCookies },
      timeout: 15000,
    });
    return res.data;
  }
}

async function bseGet(url) {
  try {
    const res = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://www.bseindia.com/',
      },
      timeout: 15000,
    });
    return res.data;
  } catch (e) {
    throw new Error(`BSE fetch failed: ${e.message}`);
  }
}

// ─── MCP Tool Definitions ─────────────────────────────────────────────────────
const TOOLS = [
  {
    name: 'get_corporate_announcements',
    description: 'Get latest corporate announcements/filings for a stock from NSE. Returns recent announcements with date, subject, and details.',
    inputSchema: {
      type: 'object',
      properties: {
        symbol: { type: 'string', description: 'NSE stock symbol e.g. RELIANCE, TATAMOTORS, HDFCBANK' },
        count: { type: 'number', description: 'Number of announcements to fetch (default 10, max 50)' },
      },
      required: ['symbol'],
    },
  },
  {
    name: 'get_result_dates',
    description: 'Get upcoming and past quarterly result dates for a stock. Shows board meeting dates for financial results.',
    inputSchema: {
      type: 'object',
      properties: {
        symbol: { type: 'string', description: 'NSE stock symbol' },
      },
      required: ['symbol'],
    },
  },
  {
    name: 'get_bulk_block_deals',
    description: 'Get recent bulk deals and block deals on NSE for a specific stock or all stocks today.',
    inputSchema: {
      type: 'object',
      properties: {
        symbol: { type: 'string', description: 'NSE stock symbol (optional — leave empty for all bulk deals today)' },
        date: { type: 'string', description: 'Date in YYYY-MM-DD format (optional, defaults to today)' },
      },
    },
  },
  {
    name: 'get_shareholding_pattern',
    description: 'Get promoter, FII, DII, and public shareholding pattern for a stock.',
    inputSchema: {
      type: 'object',
      properties: {
        symbol: { type: 'string', description: 'NSE stock symbol' },
      },
      required: ['symbol'],
    },
  },
  {
    name: 'get_fii_dii_data',
    description: 'Get today\'s or recent FII (Foreign Institutional Investors) and DII (Domestic Institutional Investors) buy/sell data for Indian markets.',
    inputSchema: {
      type: 'object',
      properties: {
        date: { type: 'string', description: 'Date in YYYY-MM-DD format (optional, defaults to today)' },
      },
    },
  },
  {
    name: 'get_stock_quote',
    description: 'Get complete stock quote with OHLC, 52-week high/low, PE ratio, market cap, and circuit limits from NSE.',
    inputSchema: {
      type: 'object',
      properties: {
        symbol: { type: 'string', description: 'NSE stock symbol' },
      },
      required: ['symbol'],
    },
  },
  {
    name: 'get_market_status',
    description: 'Get current NSE market status, indices (Nifty 50, Nifty Bank, Nifty Midcap), advances/declines, and top gainers/losers.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'get_upcoming_events',
    description: 'Get upcoming corporate events — dividends, bonus issues, rights issues, stock splits, AGMs for all NSE stocks in next 30 days.',
    inputSchema: {
      type: 'object',
      properties: {
        event_type: {
          type: 'string',
          description: 'Type of event: dividend, bonus, split, rights, agm, board_meeting (optional — leave empty for all)',
        },
        days: { type: 'number', description: 'Number of days ahead to look (default 30)' },
      },
    },
  },
  {
    name: 'get_insider_trading',
    description: 'Get recent SAST/insider trading disclosures for a stock — promoter buying/selling activity.',
    inputSchema: {
      type: 'object',
      properties: {
        symbol: { type: 'string', description: 'NSE stock symbol' },
      },
      required: ['symbol'],
    },
  },
  {
    name: 'search_announcements_by_keyword',
    description: 'Search NSE corporate announcements across all stocks by keyword — e.g. "order win", "capacity expansion", "fundraise", "merger".',
    inputSchema: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: 'Keyword to search in announcements e.g. "order win", "expansion", "QIP"' },
        days: { type: 'number', description: 'How many days back to search (default 7)' },
      },
      required: ['keyword'],
    },
  },
];

// ─── Tool Handlers ────────────────────────────────────────────────────────────

async function handle_get_corporate_announcements({ symbol, count = 10 }) {
  const sym = symbol.toUpperCase();
  const data = await nseGet(
    `https://www.nseindia.com/api/corp-info?symbol=${sym}&corpType=announcements&market=equities`
  );
  const announcements = (data?.corpAnnouncementData || []).slice(0, Math.min(count, 50));
  if (!announcements.length) return { symbol: sym, announcements: [], message: 'No announcements found' };
  return {
    symbol: sym,
    total: announcements.length,
    announcements: announcements.map(a => ({
      date: a.exchdisstime || a.attchmntText,
      subject: a.desc || a.subject,
      exchange: a.exchdisstime ? 'NSE' : 'BSE',
      attachment: a.attchmntFile ? `https://nsearchives.nseindia.com/${a.attchmntFile}` : null,
    })),
  };
}

async function handle_get_result_dates({ symbol }) {
  const sym = symbol.toUpperCase();
  const data = await nseGet(
    `https://www.nseindia.com/api/corp-info?symbol=${sym}&corpType=boardMeeting&market=equities`
  );
  const meetings = data?.corpMeetingData || [];
  return {
    symbol: sym,
    board_meetings: meetings.slice(0, 20).map(m => ({
      purpose: m.purpose,
      meeting_date: m.bm_date,
      description: m.bm_desc,
    })),
  };
}

async function handle_get_bulk_block_deals({ symbol, date }) {
  const today = date || new Date().toISOString().split('T')[0];
  const [bulk, block] = await Promise.allSettled([
    nseGet(`https://www.nseindia.com/api/bulkdeals?date=${today}`),
    nseGet(`https://www.nseindia.com/api/blockdeals?date=${today}`),
  ]);

  let bulkData = bulk.status === 'fulfilled' ? (bulk.value?.data || []) : [];
  let blockData = block.status === 'fulfilled' ? (block.value?.data || []) : [];

  if (symbol) {
    const sym = symbol.toUpperCase();
    bulkData = bulkData.filter(d => d.symbol?.toUpperCase() === sym);
    blockData = blockData.filter(d => d.symbol?.toUpperCase() === sym);
  }

  return {
    date: today,
    symbol: symbol || 'ALL',
    bulk_deals: bulkData.slice(0, 30).map(d => ({
      symbol: d.symbol,
      client: d.clientName,
      transaction: d.buySell,
      quantity: d.quantityTraded,
      price: d.tradePrice,
    })),
    block_deals: blockData.slice(0, 30).map(d => ({
      symbol: d.symbol,
      client: d.clientName,
      transaction: d.buySell,
      quantity: d.quantityTraded,
      price: d.tradePrice,
    })),
  };
}

async function handle_get_shareholding_pattern({ symbol }) {
  const sym = symbol.toUpperCase();
  const data = await nseGet(
    `https://www.nseindia.com/api/corp-info?symbol=${sym}&corpType=shareholding&market=equities`
  );
  const sh = data?.shareholdingData || data?.shareholding || [];
  return { symbol: sym, shareholding: sh.slice(0, 8) };
}

async function handle_get_fii_dii_data({ date }) {
  const data = await nseGet('https://www.nseindia.com/api/fiidiiTradeReact');
  return {
    date: date || 'latest',
    fii_dii_activity: (data || []).slice(0, 10),
  };
}

async function handle_get_stock_quote({ symbol }) {
  const sym = symbol.toUpperCase();
  const data = await nseGet(`https://www.nseindia.com/api/quote-equity?symbol=${sym}`);
  const p = data?.priceInfo || {};
  const m = data?.metadata || {};
  const s = data?.securityInfo || {};
  return {
    symbol: sym,
    company_name: m.companyName,
    series: m.series,
    last_price: p.lastPrice,
    open: p.open,
    high: p.intraDayHighLow?.max,
    low: p.intraDayHighLow?.min,
    close: p.previousClose,
    change: p.change,
    change_percent: p.pChange,
    week_52_high: p.weekHighLow?.max,
    week_52_low: p.weekHighLow?.min,
    volume: data?.marketDeptOrderBook?.tradeInfo?.totalTradedVolume,
    market_cap: s.issuedCap ? (s.issuedCap * p.lastPrice / 10000000).toFixed(0) + ' Cr' : null,
    pe_ratio: data?.industryInfo?.pe,
    upper_circuit: p.upperCP,
    lower_circuit: p.lowerCP,
    vwap: p.vwap,
  };
}

async function handle_get_market_status() {
  const [indices, advances, gainers, losers] = await Promise.allSettled([
    nseGet('https://www.nseindia.com/api/allIndices'),
    nseGet('https://www.nseindia.com/api/advances-declines?index=SECURITIES%20IN%20F%26O'),
    nseGet('https://www.nseindia.com/api/live-analysis-variations?index=gainers&type=large'),
    nseGet('https://www.nseindia.com/api/live-analysis-variations?index=losers&type=large'),
  ]);

  const keyIndices = ['NIFTY 50', 'NIFTY BANK', 'NIFTY MIDCAP 100', 'NIFTY SMALLCAP 100', 'INDIA VIX'];
  const indicesData = indices.status === 'fulfilled'
    ? (indices.value?.data || []).filter(i => keyIndices.includes(i.index)).map(i => ({
        index: i.index,
        last: i.last,
        change: i.variation,
        change_pct: i.percentChange,
      }))
    : [];

  return {
    indices: indicesData,
    advances_declines: advances.status === 'fulfilled' ? advances.value : null,
    top_gainers: gainers.status === 'fulfilled'
      ? (gainers.value?.data || []).slice(0, 5).map(g => ({ symbol: g.symbol, change_pct: g.pChange, ltp: g.ltp }))
      : [],
    top_losers: losers.status === 'fulfilled'
      ? (losers.value?.data || []).slice(0, 5).map(l => ({ symbol: l.symbol, change_pct: l.pChange, ltp: l.ltp }))
      : [],
  };
}

async function handle_get_upcoming_events({ event_type, days = 30 }) {
  const data = await nseGet('https://www.nseindia.com/api/event-calendar');
  let events = data || [];
  if (event_type) {
    const filter = event_type.toLowerCase();
    events = events.filter(e => e.purpose?.toLowerCase().includes(filter));
  }
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() + days);
  events = events.filter(e => {
    const d = new Date(e.date);
    return d >= new Date() && d <= cutoff;
  });
  return {
    event_type: event_type || 'all',
    days_ahead: days,
    count: events.length,
    events: events.slice(0, 50).map(e => ({
      symbol: e.symbol,
      company: e.company,
      date: e.date,
      purpose: e.purpose,
    })),
  };
}

async function handle_get_insider_trading({ symbol }) {
  const sym = symbol.toUpperCase();
  const data = await nseGet(
    `https://www.nseindia.com/api/corp-info?symbol=${sym}&corpType=sast&market=equities`
  );
  const sast = data?.sastData || data?.insiderData || [];
  return {
    symbol: sym,
    insider_transactions: sast.slice(0, 20).map(s => ({
      acquirer: s.acqName || s.name,
      transaction_type: s.transactionType || s.acqMode,
      shares: s.noOfShareAcq || s.shares,
      from_date: s.date || s.fromDate,
      to_date: s.toDate,
      post_holding_pct: s.postShareholdingPer || s.postHolding,
    })),
  };
}

async function handle_search_announcements_by_keyword({ keyword, days = 7 }) {
  // NSE doesn't have a keyword search API, so we fetch recent announcements
  // for top stocks and filter — practical approach
  const topStocks = [
    'RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK', 'HINDUNILVR', 'ITC',
    'SBIN', 'BAJFINANCE', 'BHARTIARTL', 'TATAMOTORS', 'AXISBANK', 'KOTAKBANK',
    'WIPRO', 'ULTRACEMCO', 'MARUTI', 'SUNPHARMA', 'TITAN', 'ADANIENT', 'LT',
  ];

  const kw = keyword.toLowerCase();
  const results = [];
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);

  const fetches = topStocks.slice(0, 10).map(sym =>
    nseGet(`https://www.nseindia.com/api/corp-info?symbol=${sym}&corpType=announcements&market=equities`)
      .then(data => {
        const ann = data?.corpAnnouncementData || [];
        ann.forEach(a => {
          const subject = (a.desc || a.subject || '').toLowerCase();
          if (subject.includes(kw)) {
            results.push({
              symbol: sym,
              date: a.exchdisstime,
              subject: a.desc || a.subject,
            });
          }
        });
      })
      .catch(() => {})
  );

  await Promise.allSettled(fetches);

  return {
    keyword,
    days_searched: days,
    matches_found: results.length,
    results: results.slice(0, 20),
    note: 'Searched top 10 NSE stocks. For comprehensive search across all stocks, deploy with a full symbol list.',
  };
}

// ─── MCP Protocol Endpoints ───────────────────────────────────────────────────

// SSE endpoint for Claude.ai connector
app.get('/mcp', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');

  // Send server info
  res.write(`data: ${JSON.stringify({
    jsonrpc: '2.0',
    method: 'notifications/initialized',
    params: { serverInfo: { name: 'nse-bse-mcp', version: '1.0.0' } }
  })}\n\n`);

  req.on('close', () => res.end());
});

// Main MCP JSON-RPC handler
app.post('/mcp', async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  const { method, params, id } = req.body;

  try {
    if (method === 'initialize') {
      return res.json({
        jsonrpc: '2.0', id,
        result: {
          protocolVersion: '2024-11-05',
          serverInfo: { name: 'nse-bse-mcp', version: '1.0.0' },
          capabilities: { tools: {} },
        },
      });
    }

    if (method === 'tools/list') {
      return res.json({ jsonrpc: '2.0', id, result: { tools: TOOLS } });
    }

    if (method === 'tools/call') {
      const { name, arguments: args } = params;
      const handlers = {
        get_corporate_announcements: handle_get_corporate_announcements,
        get_result_dates: handle_get_result_dates,
        get_bulk_block_deals: handle_get_bulk_block_deals,
        get_shareholding_pattern: handle_get_shareholding_pattern,
        get_fii_dii_data: handle_get_fii_dii_data,
        get_stock_quote: handle_get_stock_quote,
        get_market_status: handle_get_market_status,
        get_upcoming_events: handle_get_upcoming_events,
        get_insider_trading: handle_get_insider_trading,
        search_announcements_by_keyword: handle_search_announcements_by_keyword,
      };

      const handler = handlers[name];
      if (!handler) throw new Error(`Unknown tool: ${name}`);

      const result = await handler(args || {});
      return res.json({
        jsonrpc: '2.0', id,
        result: {
          content: [{ type: 'text', text: JSON.stringify(result, null, 2) }],
        },
      });
    }

    // Handle notifications (no response needed)
    if (method?.startsWith('notifications/')) {
      return res.status(204).end();
    }

    res.json({ jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } });

  } catch (err) {
    console.error(`[${method}] Error:`, err.message);
    res.json({
      jsonrpc: '2.0', id,
      error: { code: -32000, message: err.message },
    });
  }
});

app.options('/mcp', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(204).end();
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', server: 'nse-bse-mcp', tools: TOOLS.length, timestamp: new Date().toISOString() });
});

// Warm up NSE cookies on start
getNSECookies().then(() => console.log('✅ NSE cookies initialized'));

const PORT = process.env.PORT || 3005;
app.listen(PORT, () => {
  console.log(`🚀 NSE/BSE MCP Server running on port ${PORT}`);
  console.log(`📡 MCP endpoint: http://localhost:${PORT}/mcp`);
  console.log(`🔧 Tools available: ${TOOLS.map(t => t.name).join(', ')}`);
});
